function p=evaluate2(X,theta)
	p=[1 X]*theta;
end

